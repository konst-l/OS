﻿#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <chrono>
#include <thread>
#include <mutex>
#include <algorithm>
#include <iomanip>

using namespace std;

mutex file_mutex;
mutex result_mutex;

class Matrix {
public:
    vector<vector<int>> data;
    int rows, cols;

    Matrix(int n) : rows(n), cols(n), data(n, vector<int>(n, 0)) {}

    static vector<Matrix> read_from_file(const string& filename) {
        ifstream file(filename);
        vector<Matrix> matrices;

        int n;
        file >> n;

        Matrix A(n), B(n);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                file >> A.data[i][j];
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                file >> B.data[i][j];
            }
        }

        file.close();

        matrices.push_back(A);
        matrices.push_back(B);
        return matrices;
    }
};

void mult_block(int i, int j, int k, const Matrix& A, const Matrix& B, Matrix& C) {

    int n = A.rows;
    int start_i = i * k;
    int end_i = min(start_i + k, n);
    int start_j = j * k;
    int end_j = min(start_j + k, n);

    for (int i = start_i; i < end_i; i++) {
        for (int j = start_j; j < end_j; j++) {
            int sum = 0;
            for (int kk = 0; kk < n; kk++) {
                sum += A.data[i][kk] * B.data[kk][j];
            }

            result_mutex.lock();
            C.data[i][j] = sum;
            result_mutex.unlock();
        }
    }
}

void write(const string& method, int block_size, long long time, int threads_count, int matrix_size) {

    file_mutex.lock();
    ofstream file("time.txt", ios::app);
    if (file.is_open()) {
        file << "Method: " << method << "  Block size: " << block_size << "  Time: " <<
            time << " Threads: " << threads_count << "  Matrix_size: " << matrix_size << endl;
        file.close();
    }
    file_mutex.unlock();
}

Matrix mult_sequential(const Matrix& A, const Matrix& B) {
    int n = A.rows;
    Matrix C(n);

    auto start = chrono::high_resolution_clock::now();

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                C.data[i][j] += A.data[i][k] * B.data[k][j];
            }
        }
    }

    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end - start);

    write("Simple", 0, duration.count(), 1, n);

    return C;
}

Matrix mult_thread(const Matrix& A, const Matrix& B, int k) {
    int n = A.rows;
    Matrix C(n);
    vector<thread> threads;

    int kol = (n + k - 1) / k;

    auto start = chrono::high_resolution_clock::now();

    for (int i = 0; i < kol; i++) {
        for (int j = 0; j < kol; j++) {
            threads.emplace_back(mult_block, i, j, k, ref(A), ref(B), ref(C));
        }
    }

    for (auto& t : threads) {
        t.join();
    }

    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end - start);

    write("Threads", k, duration.count(), threads.size(), n);

    return C;
}

int main() {
    setlocale(LC_ALL, "");

    vector<Matrix> matrices = Matrix::read_from_file("input.txt");

    Matrix A = matrices[0];
    Matrix B = matrices[1];

    Matrix C_seq = mult_sequential(A, B);

    int n = A.rows;

    for (int k = 1; k <= n; k++) {
        cout << "\n>>> Размер блока: " << k << endl;
        Matrix C_thread = mult_thread(A, B, k);

        bool correct = true;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (C_seq.data[i][j] != C_thread.data[i][j]) {
                    correct = false;
                    break;
                }
            }
            if (!correct) break;
        }

        if (correct) {
            cout << "Correct" << endl;
        }
        else {
            cout << "Incorrect" << endl;
        }
    }


    return 0;
}