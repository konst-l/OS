﻿#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <mutex>
#include <algorithm>
#include <iomanip>

using namespace std;

mutex result_mutex;

class Matrix {
public:
    vector<vector<int>> data;
    int size;

    Matrix(int n) : size(n), data(n, vector<int>(n, 0)) {}

    void fill_random() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                data[i][j] = rand() % 10;
            }
        }
    }
};

void mult_block(int iB, int jB, int kB, int k, int n,
    const Matrix& A, const Matrix& B, Matrix& C) {
    int start_i = iB * k;
    int start_j = jB * k;
    int start_k = kB * k;

    for (int i = 0; i < k && (start_i + i) < n; i++) {
        for (int j = 0; j < k && (start_j + j) < n; j++) {
            int partial_sum = 0;
            for (int x = 0; x < k && (start_k + x) < n; x++) {
                partial_sum += A.data[start_i + i][start_k + x] * B.data[start_k + x][start_j + j];
            }

            lock_guard<mutex> lock(result_mutex);
            C.data[start_i + i][start_j + j] += partial_sum;
        }
    }
}

long long run_sequential(const Matrix& A, const Matrix& B, Matrix& C_seq) {
    int n = A.size;
    auto start = chrono::high_resolution_clock::now();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                C_seq.data[i][j] += A.data[i][k] * B.data[k][j];
            }
        }
    }
    auto end = chrono::high_resolution_clock::now();
    return chrono::duration_cast<chrono::microseconds>(end - start).count();
}

int main() {
    setlocale(LC_ALL, "rus");
    srand(time(0));

    int N, k_input;
    cout << "Размер матрицы N (больше чем 4): ";
    cin >> N;
    cout << "Размер блока k (1-" << N << "): ";
    cin >> k_input;

    Matrix A(N), B(N), C_ref(N), C_parallel(N);
    A.fill_random();
    B.fill_random();

    long long seq_time = run_sequential(A, B, C_ref);

    int num_blocks = (N + k_input - 1) / k_input;
    vector<thread> threads;

    auto p_start = chrono::high_resolution_clock::now();
    for (int i = 0; i < num_blocks; i++)
        for (int j = 0; j < num_blocks; j++)
            for (int t = 0; t < num_blocks; t++)
                threads.emplace_back(mult_block, i, j, t, k_input, N, ref(A), ref(B), ref(C_parallel));

    for (auto& t : threads) t.join();
    auto p_end = chrono::high_resolution_clock::now();
    long long par_time = chrono::duration_cast<chrono::microseconds>(p_end - p_start).count();

    bool correct = true;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            if (C_ref.data[i][j] != C_parallel.data[i][j]) correct = false;

    cout << "\nРЕЗУЛЬТАТЫ ДЛЯ ВВЕДЕННОГО k=" << k_input << endl;
    cout << "Матрица: " << N << "x" << N << endl;
    cout << "Всего потоков: " << threads.size() << endl;
    cout << "Время (параллельно): " << par_time << " мкс" << endl;
    cout << "Время (последовательно): " << seq_time << " мкс" << endl;
    cout << "Ускорение: " << fixed << setprecision(2) << (double)seq_time / par_time << "x" << endl;
    cout << "Корректность: " << (correct ? "OK" : "ОШИБКА") << endl;

    cout << "\nСРАВНИТЕЛЬНАЯ ТАБЛИЦА" << endl;
    cout << left << setw(5) << "k" << setw(10) << "Блоков" << setw(10) << "Потоков" << setw(15) << "Время (мкс)" << "Ускорение" << endl;
    cout << string(55, '-') << endl;

    for (int k = 1; k <= N; k++) {
        Matrix C_test(N);
        vector<thread> test_threads;
        int current_blocks = (N + k - 1) / k;

        auto t_start = chrono::high_resolution_clock::now();
        for (int i = 0; i < current_blocks; i++)
            for (int j = 0; j < current_blocks; j++)
                for (int t = 0; t < current_blocks; t++)
                    test_threads.emplace_back(mult_block, i, j, t, k, N, ref(A), ref(B), ref(C_test));

        for (auto& t : test_threads) t.join();
        auto t_end = chrono::high_resolution_clock::now();
        long long t_dur = chrono::duration_cast<chrono::microseconds>(t_end - t_start).count();

        cout << left << setw(5) << k << setw(10) << current_blocks << setw(10) << test_threads.size()
            << setw(15) << t_dur << fixed << setprecision(2) << (double)seq_time / t_dur << "x" << endl;
    }

    return 0;
}