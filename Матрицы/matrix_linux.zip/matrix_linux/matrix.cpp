#include <iostream>
#include <vector>
#include <fstream>
#include <chrono>
#include <pthread.h>
#include <algorithm>
#include <climits>
using namespace std;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
ofstream out("results.txt");

struct Data {
    long long i, j, k, n;
    const vector<vector<long long>> *A;
    const vector<vector<long long>> *B;
    vector<vector<long long>> *C;
    
    Data(long long i, long long j, long long k, long long n, 
         const vector<vector<long long>>* A, 
         const vector<vector<long long>>* B, 
         vector<vector<long long>>* C)
        : i(i), j(j), k(k), n(n), A(A), B(B), C(C) {}
};

void* multiply_block(void* arg) {
    Data* d = (Data*)arg;
    long long start_i = d->i * d->k;
    long long end_i = min(start_i + d->k, d->n);
    long long start_j = d->j * d->k;
    long long end_j = min(start_j + d->k, d->n);
    
    for (long long ii = start_i; ii < end_i; ii++) {
        for (long long jj = start_j; jj < end_j; jj++) {
            long long sum = 0;
            for (long long kk = 0; kk < d->n; kk++) {
                sum += (*d->A)[ii][kk] * (*d->B)[kk][jj];
            }
            pthread_mutex_lock(&mutex);
            (*d->C)[ii][jj] = sum;
            pthread_mutex_unlock(&mutex);
        }
    }
    delete d;
    return NULL;
}

int main() {
    ifstream fin("input.txt");
    if (!fin.is_open()) {
        cerr << "Ошибка: не могу открыть input.txt\n";
        return 1;
    }
    
    int n; 
    fin >> n;
    
    if (n <= 0) {
        cerr << "Ошибка: неверный размер матрицы\n";
        return 1;
    }
    
    vector<vector<long long>> A(n, vector<long long>(n)), 
                             B(n, vector<long long>(n)), 
                             C_seq(n, vector<long long>(n)), 
                             C_par(n, vector<long long>(n));
    
    for(int i=0; i<n; i++) {
        for(int j=0; j<n; j++) {
            fin >> A[i][j];
        }
    }
    
    for(int i=0; i<n; i++) {
        for(int j=0; j<n; j++) {
            fin >> B[i][j];
        }
    }
    
    fin.close();
    
    
    auto start = chrono::high_resolution_clock::now();
    for(int i=0; i<n; i++) {
        for(int j=0; j<n; j++) {
            long long sum = 0;
            for(int k=0; k<n; k++) {
                sum += A[i][k] * B[k][j];
            }
            C_seq[i][j] = sum;
        }
    }
    
    auto end = chrono::high_resolution_clock::now();
    long seq_time = chrono::duration_cast<chrono::microseconds>(end-start).count();
    
    out << "РЕЗУЛЬТАТЫ УМНОЖЕНИЯ МАТРИЦ" << n << "x" << n << " ===\n";
    out << "Все размеры блоков от 1 до " << n << "\n";
    out << "Последовательный алгоритм: " << seq_time << " мкс\n\n";
    out << "Параллельный алгоритм (pthread):\n";
    out << "Блок\tВремя(мкс)\tПотоков\tУскорение\tСтатус\n";
    out << "----------------------------------------------------------------\n";
    
    cout << "Последовательное: " << seq_time << " μs\n";
    cout << "\nБлок\tВремя\t\tПотоков\tУскорение\tСтатус\n";
    cout << "----------------------------------------------------------\n";
    
    for(int k = 2; k <= n; k++) {
        for(int i=0; i<n; i++) {
            fill(C_par[i].begin(), C_par[i].end(), 0);
        }
        
        vector<pthread_t> threads;
        int blocks_i = (n + k - 1) / k;
        int blocks_j = (n + k - 1) / k;
        int total_threads = blocks_i * blocks_j;
        
        start = chrono::high_resolution_clock::now();
        
        for(int i=0; i<blocks_i; i++) {
            for(int j=0; j<blocks_j; j++) {
                Data* data = new Data(i, j, k, n, &A, &B, &C_par);
                pthread_t th;
                pthread_create(&th, NULL, multiply_block, data);
                threads.push_back(th);
            }
        }
        
        for(auto& th : threads) {
            pthread_join(th, NULL);
        }
        
        end = chrono::high_resolution_clock::now();
        long par_time = chrono::duration_cast<chrono::microseconds>(end-start).count();
        
        bool correct = true;
        for(int i=0; i<n && correct; i++) {
            for(int j=0; j<n && correct; j++) {
                if(C_seq[i][j] != C_par[i][j]) {
                    correct = false;
                    break;
                }
            }
        }
        
        double speedup = (seq_time == 0) ? 1.0 : (double)seq_time / max(par_time, 1L);
        
        out << k << "\t" << par_time << "\t\t" << total_threads << "\t";
        if (speedup >= 1.0) {
            out << speedup << "x быстрее\t";
        } else {
            out << (1.0/speedup) << "x медленнее\t";
        }
        out << (correct ? "OK" : "ERROR") << "\n";
        
        printf("%3d\t%7ld\t%7d\t%8.2fx\t\t%s\n", 
               k, par_time, total_threads, speedup, correct?"OK":"ERROR");
        
    }
    
    long long max_val = 0;
    for(int i=0; i<n; i++) {
        for(int j=0; j<n; j++) {
            if(C_seq[i][j] > max_val) {
                max_val = C_seq[i][j];
            }
        }
    }
    
    
   
    
    cout << "Тестирование завершено!\n";
    cout << "Все результаты записаны в файл results.txt\n";
    cout << "Протестировано " << n << " различных размеров блоков\n";
    
    return 0;
}


