#include <iostream>
#include <vector>
#include <fstream>
#include <chrono>
#include <windows.h>
#include <algorithm>

using namespace std;

CRITICAL_SECTION file_cs;

class Matrix {
public:
    vector<vector<int>> data;
    int rows, cols;

    Matrix(int n) : rows(n), cols(n), data(n, vector<int>(n, 0)) {}

    static vector<Matrix> read_from_file(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "������: �� ������� ������� ���� " << filename << endl;
            exit(1);
        }

        int n;
        file >> n;

        Matrix A(n), B(n);

        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                file >> A.data[i][j];

        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                file >> B.data[i][j];

        cout << "Matrix size: " << n << "x" << n << endl;
        cout << "First element of A: " << A.data[0][0] << endl;
        cout << "Last element of B: " << B.data[n - 1][n - 1] << endl;

        file.close();
        return { A, B };
    }
};

struct ThreadData {
    int bi, bj, block_size;
    Matrix* A;
    Matrix* B;
    Matrix* C;
};

void write_log(const string& method, int block_size, long long time, int threads_count, int matrix_size) {
    EnterCriticalSection(&file_cs);

    ofstream file("time.txt", ios::app);
    if (file.is_open()) {
        file << "Method: " << method
            << " | Block size: " << block_size
            << " | Time: " << time
            << " �s | Threads: " << threads_count
            << " | Matrix size: " << matrix_size << endl;
        file.close();
    }

    LeaveCriticalSection(&file_cs);
}

Matrix mult_sequential(const Matrix& A, const Matrix& B) {
    int n = A.rows;
    Matrix C(n);

    auto start = chrono::high_resolution_clock::now();

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            for (int k = 0; k < n; k++)
                C.data[i][j] += A.data[i][k] * B.data[k][j];

    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end - start);

    write_log("Sequential", 0, duration.count(), 1, n);
    return C;
}

DWORD WINAPI mult_block_winapi(LPVOID lpParam) {
    ThreadData* data = (ThreadData*)lpParam;

    int n = data->A->rows;
    int block = data->block_size;

    int start_i = data->bi * block;
    int end_i = min(start_i + block, n);
    int start_j = data->bj * block;
    int end_j = min(start_j + block, n);

    for (int row = start_i; row < end_i; row++) {
        for (int col = start_j; col < end_j; col++) {
            int sum = 0;
            for (int kk = 0; kk < n; kk++)
                sum += data->A->data[row][kk] * data->B->data[kk][col];

            data->C->data[row][col] = sum;
        }
    }

    delete data;
    return 0;
}

Matrix mult_thread_winapi(const Matrix& A, const Matrix& B, int block_size) {
    int n = A.rows;
    Matrix C(n);

    vector<HANDLE> threads;
    int blocks = (n + block_size - 1) / block_size;

    auto start = chrono::high_resolution_clock::now();

    for (int bi = 0; bi < blocks; bi++) {
        for (int bj = 0; bj < blocks; bj++) {
            ThreadData* data = new ThreadData{ bi, bj, block_size, const_cast<Matrix*>(&A), const_cast<Matrix*>(&B), &C };
            HANDLE hThread = CreateThread(NULL, 0, mult_block_winapi, data, 0, NULL);

            if (hThread)
                threads.push_back(hThread);
            else {
                cerr << "������ �������� ������!" << endl;
                delete data;
            }
        }
    }

    for (HANDLE h : threads) {
        WaitForSingleObject(h, INFINITE);
        CloseHandle(h);
    }

    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end - start);

    write_log("Threaded", block_size, duration.count(), static_cast<int>(threads.size()), n);
    return C;
}

int main() {
    setlocale(LC_ALL, "");
    InitializeCriticalSection(&file_cs);

    vector<Matrix> matrices = Matrix::read_from_file("input.txt");
    Matrix A = matrices[0];
    Matrix B = matrices[1];
    int n = A.rows;

    Matrix C_seq = mult_sequential(A, B);

    for (int k = 1; k <= n; k++) {
        cout << "\n>>> Block size: " << k << endl;
        Matrix C_thread = mult_thread_winapi(A, B, k);

        bool correct = true;
        for (int i = 0; i < n && correct; i++)
            for (int j = 0; j < n; j++)
                if (C_seq.data[i][j] != C_thread.data[i][j]) {
                    cout << "Mismatch at [" << i << "][" << j << "]: seq=" << C_seq.data[i][j]
                        << " thread=" << C_thread.data[i][j] << endl;
                        correct = false;
                        break;
                }

        cout << (correct ? "Correct" : "Incorrect") << endl;
    }

    DeleteCriticalSection(&file_cs);
    return 0;
}
