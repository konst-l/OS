#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>

int main() {
    setlocale(LC_ALL, "Russian");

    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };

    HANDLE hMA_read, hMA_write;
    CreatePipe(&hMA_read, &hMA_write, &sa, 0);

    HANDLE hAP_read, hAP_write;
    CreatePipe(&hAP_read, &hAP_write, &sa, 0);

    HANDLE hPS_read, hPS_write;
    CreatePipe(&hPS_read, &hPS_write, &sa, 0);

    HANDLE hSM_read, hSM_write;
    CreatePipe(&hSM_read, &hSM_write, &sa, 0);

    std::string input;
    std::getline(std::cin, input);

    std::vector<int> data;
    std::stringstream ss(input);
    int num;
    while (ss >> num) {
        data.push_back(num);
    }

    if (data.empty()) {
        std::cout << "�� ������� �� ������ �����!" << std::endl;
        return 0;
    }

    STARTUPINFOA siS = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION piS;
    siS.dwFlags = STARTF_USESTDHANDLES;
    siS.hStdInput = hPS_read;
    siS.hStdOutput = hSM_write;
    siS.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    char processS[] = "PROCESS_S.exe";
    if (!CreateProcessA(NULL, processS, NULL, NULL, TRUE, 0, NULL, NULL, &siS, &piS)) {
        std::cerr << "������ ������� PROCESS_S.exe" << std::endl;
        return 1;
    }
    CloseHandle(hPS_read);
    CloseHandle(hSM_write);

    STARTUPINFOA siP = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION piP;
    siP.dwFlags = STARTF_USESTDHANDLES;
    siP.hStdInput = hAP_read;
    siP.hStdOutput = hPS_write;
    siP.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    char processP[] = "PROCESS_P.exe";
    if (!CreateProcessA(NULL, processP, NULL, NULL, TRUE, 0, NULL, NULL, &siP, &piP)) {
        std::cerr << "������ ������� PROCESS_P.exe" << std::endl;
        return 1;
    }
    CloseHandle(hAP_read);
    CloseHandle(hPS_write);

    STARTUPINFOA siA = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION piA;
    siA.dwFlags = STARTF_USESTDHANDLES;
    siA.hStdInput = hMA_read;
    siA.hStdOutput = hAP_write;
    siA.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    char processA[] = "PROCESS_A.exe";
    if (!CreateProcessA(NULL, processA, NULL, NULL, TRUE, 0, NULL, NULL, &siA, &piA)) {
        std::cerr << "������ ������� PROCESS_A.exe" << std::endl;
        return 1;
    }
    CloseHandle(hMA_read);
    CloseHandle(hAP_write);

    STARTUPINFOA siM = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION piM;
    siM.dwFlags = STARTF_USESTDHANDLES;

    HANDLE hIn_read, hIn_write;
    CreatePipe(&hIn_read, &hIn_write, &sa, 0);

    siM.hStdInput = hIn_read;
    siM.hStdOutput = hMA_write;
    siM.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    char processM[] = "PROCESS_M.exe";
    if (!CreateProcessA(NULL, processM, NULL, NULL, TRUE, 0, NULL, NULL, &siM, &piM)) {
        std::cerr << "������ ������� PROCESS_M.exe" << std::endl;
        return 1;
    }
    CloseHandle(hIn_read);
    CloseHandle(hMA_write);

    DWORD written;
    for (int num : data) {
        WriteFile(hIn_write, &num, sizeof(int), &written, NULL);
    }

    int endMark = 0;
    WriteFile(hIn_write, &endMark, sizeof(int), &written, NULL);
    CloseHandle(hIn_write);

    WaitForSingleObject(piM.hProcess, INFINITE);
    WaitForSingleObject(piA.hProcess, INFINITE);
    WaitForSingleObject(piP.hProcess, INFINITE);
    WaitForSingleObject(piS.hProcess, INFINITE);

    int result;
    DWORD read;
    if (ReadFile(hSM_read, &result, sizeof(int), &read, NULL) && read > 0) {
        std::cout << "��������� ���������: " << result << std::endl;
    }
    else {
        std::cout << "�� ������� �������� ���������" << std::endl;
    }

    CloseHandle(piM.hThread);
    CloseHandle(piM.hProcess);
    CloseHandle(piA.hThread);
    CloseHandle(piA.hProcess);
    CloseHandle(piP.hThread);
    CloseHandle(piP.hProcess);
    CloseHandle(piS.hThread);
    CloseHandle(piS.hProcess);
    CloseHandle(hSM_read);

    return 0;
}