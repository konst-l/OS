#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cmath>

#define BUFFER_SIZE 1024

const int N = 11; 

int main() {
    setlocale(LC_ALL, "Russian");

    std::string input;
    std::cout << "������� ����� ����� ������: ";
    std::getline(std::cin, input);

    std::stringstream ss(input);
    std::vector<int> numbers;
    int num;
    while (ss >> num) {
        numbers.push_back(num);
    }

    if (numbers.empty()) {
        std::cout << "��� ����� ��� ���������." << std::endl;
        return 0;
    }

    HANDLE hPipeMA[2], hPipeAP[2], hPipePS[2];
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };

    CreatePipe(&hPipeMA[0], &hPipeMA[1], &sa, 0);
    CreatePipe(&hPipeAP[0], &hPipeAP[1], &sa, 0);
    CreatePipe(&hPipePS[0], &hPipePS[1], &sa, 0);

    DWORD written;
    for (int n : numbers) {
        WriteFile(hPipeMA[1], &n, sizeof(int), &written, NULL);
    }
    CloseHandle(hPipeMA[1]); 

    int x;
    DWORD bytesRead, bytesWritten;
    while (ReadFile(hPipeMA[0], &x, sizeof(int), &bytesRead, NULL) && bytesRead > 0) {
        x *= 7;
        WriteFile(hPipeAP[1], &x, sizeof(int), &bytesWritten, NULL);
    }
    CloseHandle(hPipeMA[0]);
    CloseHandle(hPipeAP[1]);

    while (ReadFile(hPipeAP[0], &x, sizeof(int), &bytesRead, NULL) && bytesRead > 0) {
        x += N;
        WriteFile(hPipePS[1], &x, sizeof(int), &bytesWritten, NULL);
    }
    CloseHandle(hPipeAP[0]);
    CloseHandle(hPipePS[1]);

    std::vector<int> cubedNumbers;
    while (ReadFile(hPipePS[0], &x, sizeof(int), &bytesRead, NULL) && bytesRead > 0) {
        x = static_cast<int>(pow(x, 3));
        cubedNumbers.push_back(x);
    }
    CloseHandle(hPipePS[0]);

    int sum = 0;
    for (int val : cubedNumbers) {
        sum += val;
    }

    std::cout << "����� ����� ������� ��������������: " << sum << std::endl;

    return 0;
}