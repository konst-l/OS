#include <iostream>

int main()
{
    long long x;
    while (std::cin >> x)
    {
        std::cout << x * 7 << " ";
    }
    return 0;
}
