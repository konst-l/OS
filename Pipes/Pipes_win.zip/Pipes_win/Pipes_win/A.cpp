#include <iostream>

int main()
{
    const int N = 11;
    long long x;
    while (std::cin >> x)
    {
        std::cout << x + N << " ";
    }
    return 0;
}
