﻿#include <windows.h>
#include <iostream>
#include <string>

int main()
{
    system("g++ -o process_M.exe process_M.cpp");
    system("g++ -o process_A.exe process_A.cpp");
    system("g++ -o process_P.exe process_P.cpp");
    system("g++ -o process_S.exe process_S.cpp");

    SECURITY_ATTRIBUTES sa{ sizeof(sa), NULL, TRUE };

    HANDLE r0, w0, r1, w1, r2, w2, r3, w3;
    CreatePipe(&r0, &w0, &sa, 0);
    CreatePipe(&r1, &w1, &sa, 0);
    CreatePipe(&r2, &w2, &sa, 0);
    CreatePipe(&r3, &w3, &sa, 0);

    STARTUPINFOA si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    PROCESS_INFORMATION piM{}, piA{}, piP{}, piS{};

    // M
    si.hStdInput = r0;
    si.hStdOutput = w1;
    CreateProcessA(NULL, (LPSTR)"process_M.exe", NULL, NULL, TRUE, 0, NULL, NULL, &si, &piM);

    // A
    si.hStdInput = r1;
    si.hStdOutput = w2;
    CreateProcessA(NULL, (LPSTR)"process_A.exe", NULL, NULL, TRUE, 0, NULL, NULL, &si, &piA);

    // P
    si.hStdInput = r2;
    si.hStdOutput = w3;
    CreateProcessA(NULL, (LPSTR)"process_P.exe", NULL, NULL, TRUE, 0, NULL, NULL, &si, &piP);

    // S (пишет в консоль)
    si.hStdInput = r3;
    si.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    CreateProcessA(NULL, (LPSTR)"process_S.exe", NULL, NULL, TRUE, 0, NULL, NULL, &si, &piS);

    // ввод
    std::string line;
    std::getline(std::cin, line);
    line += "\n";

    DWORD written;
    WriteFile(w0, line.c_str(), (DWORD)line.size(), &written, NULL);
    CloseHandle(w0); // EOF для M

    // закрываем ненужные концы
    CloseHandle(r0); CloseHandle(r1); CloseHandle(w1);
    CloseHandle(r2); CloseHandle(w2);
    CloseHandle(r3); CloseHandle(w3);

    // 🔥 ВАЖНО: ждём S
    WaitForSingleObject(piS.hProcess, INFINITE);

    // чистим хэндлы
    CloseHandle(piM.hProcess); CloseHandle(piM.hThread);
    CloseHandle(piA.hProcess); CloseHandle(piA.hThread);
    CloseHandle(piP.hProcess); CloseHandle(piP.hThread);
    CloseHandle(piS.hProcess); CloseHandle(piS.hThread);

    return 0;
}
