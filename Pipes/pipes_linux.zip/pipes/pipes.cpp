#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <unistd.h>
#include <sys/wait.h>

const int N = 11; 

void processM() {
    int x;
    while (std::cin >> x) {
        std::cout << x * 7 << std::endl;
    }
}

void processA() {
    int x;
    while (std::cin >> x) {
        std::cout << x + N << std::endl;
    }
}

void processP() {
    int x;
    while (std::cin >> x) {
        std::cout << x * x * x << std::endl;
    }
}

void processS() {
    int x;
    long long sum = 0;
    while (std::cin >> x) {
        sum += x;
    }
    std::cout << "Результат: " << sum << std::endl;
}

int main() {

    std::string input;
    std::cout << "Введите числа через пробел (завершите Enter): ";
    std::getline(std::cin, input);
    
    if (input.empty()) {
        input = "1 2 3 4 5"; 
        std::cout << "Используются данные по умолчанию: " << input << std::endl;
    }
    
    input += "\n";
    
    std::cout << "\nЗапускаем цепочку процессов..." << std::endl;
    std::cout << "Цепочка: M(x*7) -> A(x+" << N << ") -> P(x^3) -> S(сумма)\n" << std::endl;
    
    int pipe1[2], pipe2[2], pipe3[2];
    
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1) {
        std::cerr << "Ошибка создания pipe" << std::endl;
        return 1;
    }
    
    pid_t input_pid = fork();
    if (input_pid == 0) {
        
        int data_pipe[2];
        pipe(data_pipe);
        
        write(data_pipe[1], input.c_str(), input.length());
        close(data_pipe[1]);
        
        dup2(data_pipe[0], STDIN_FILENO);
        dup2(pipe1[1], STDOUT_FILENO);
        
        close(data_pipe[0]);
        close(pipe1[0]); close(pipe1[1]);
        close(pipe2[0]); close(pipe2[1]);
        close(pipe3[0]); close(pipe3[1]);
        
        processM();
        exit(0);
    }
    
    
    if (fork() == 0) {
        dup2(pipe1[0], STDIN_FILENO);
        dup2(pipe2[1], STDOUT_FILENO);
        
        close(pipe1[0]); close(pipe1[1]);
        close(pipe2[0]); close(pipe2[1]);
        close(pipe3[0]); close(pipe3[1]);
        
        processA();
        exit(0);
    }
    
    if (fork() == 0) {
        dup2(pipe2[0], STDIN_FILENO);
        dup2(pipe3[1], STDOUT_FILENO);
        
        close(pipe1[0]); close(pipe1[1]);
        close(pipe2[0]); close(pipe2[1]);
        close(pipe3[0]); close(pipe3[1]);
        
        processP();
        exit(0);
    }
    
    if (fork() == 0) {
        dup2(pipe3[0], STDIN_FILENO);
        
        close(pipe1[0]); close(pipe1[1]);
        close(pipe2[0]); close(pipe2[1]);
        close(pipe3[0]); close(pipe3[1]);
        
        processS();
        exit(0);
    }
    
    close(pipe1[0]); 
    close(pipe1[1]);
    close(pipe2[0]);
    close(pipe2[1]);
    close(pipe3[0]);
    close(pipe3[1]);
    
    for (int i = 0; i < 5; i++) {
        wait(NULL);
    }
    
    return 0;
}


