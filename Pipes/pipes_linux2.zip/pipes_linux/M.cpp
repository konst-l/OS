#include<iostream>
int main()
{
    double x;
    while(std::cin>>x) {
        std::cout << x * 7 << " ";
    }
    return 0;
}