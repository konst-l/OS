#include<iostream>
int main()
{
    double x;
    while(std::cin>>x) {
        std::cout << (x*x*x) << " ";
    }
    return 0;
}