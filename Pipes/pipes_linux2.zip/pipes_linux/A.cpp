#include<iostream>
int main()
{
    int N = 11;
    double x;
    while(std::cin>>x) {
        std::cout << x + N << " ";
    }
    return 0;
}