#include<iostream>
int main()
{
    double x, sum = 0;
    while(std::cin>>x) {
        sum += x;
    }
    std::cout << sum;
    return 0;
}