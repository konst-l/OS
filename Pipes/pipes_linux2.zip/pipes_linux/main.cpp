#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

void runProcess(int in_fd, int out_fd, const char* cmd) {
    pid_t pid = fork();
    if (pid == 0) {
        if (in_fd != STDIN_FILENO) {
            dup2(in_fd, STDIN_FILENO);
            close(in_fd);
        }
        if (out_fd != STDOUT_FILENO) {
            dup2(out_fd, STDOUT_FILENO);
            close(out_fd);
        }
        for (int i = 3; i < 20; i++) close(i);
        
        execl(cmd, cmd, NULL);
        _exit(1);
    }
}

int main() {
    int p1[2], p2[2], p3[2];

    if (pipe(p1) < 0 || pipe(p2) < 0 || pipe(p3) < 0) return 1;

    runProcess(STDIN_FILENO, p1[1], "./M");
    close(p1[1]);

    runProcess(p1[0], p2[1], "./A");
    close(p1[0]); close(p2[1]);

    runProcess(p2[0], p3[1], "./P");
    close(p2[0]); close(p3[1]);

    runProcess(p3[0], STDOUT_FILENO, "./S");
    close(p3[0]);

    std::cout << "Введите числа через пробел. Для получения результата нажмите Ctrl+D:" << std::endl;

    while (wait(NULL) > 0);

    return 0;
}

