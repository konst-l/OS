#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <dirent.h>
#include <signal.h>
#include <unistd.h>
#include <fstream>

class ProcessKiller {
public:
    static void killById(pid_t pid) {
        if (kill(pid, SIGKILL) == 0) {
            std::cout << "Процесс " << pid << " завершен" << std::endl;
        }
    }

    static void killByName(const std::string& name) {
        DIR* dir = opendir("/proc");
        if (!dir) return;
        struct dirent* entry;
        while ((entry = readdir(dir)) != nullptr) {
            if (isdigit(entry->d_name[0])) {
                std::ifstream commFile("/proc/" + std::string(entry->d_name) + "/comm");
                std::string comm;
                if (getline(commFile, comm) && comm == name) {
                    killById(std::stoi(entry->d_name));
                }
            }
        }
        closedir(dir);
    }

    static void killFromEnv() {
        char* envVal = getenv("PROC_TO_KILL");
        if (!envVal) return;
        std::stringstream ss(envVal);
        std::string name;
        while (getline(ss, name, ',')) {
            if (!name.empty()) killByName(name);
        }
    }
};

int main(int argc, char* argv[]) {
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--id" && i + 1 < argc) {
            ProcessKiller::killById(std::stoi(argv[++i]));
        } else if (arg == "--name" && i + 1 < argc) {
            ProcessKiller::killByName(argv[++i]);
        } else if (arg == "--env") {
            ProcessKiller::killFromEnv();
        }
    }
    return 0;
}


