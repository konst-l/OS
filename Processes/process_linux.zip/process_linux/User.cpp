#include <iostream>
#include <string>
#include <unistd.h>
#include <fstream>
#include <dirent.h>
#include <signal.h>

class ProcessManager {
public:
    static pid_t findPid(const std::string& name) {
        DIR* dir = opendir("/proc");
        if (!dir) return 0;
        struct dirent* entry;
        while ((entry = readdir(dir)) != nullptr) {
            if (isdigit(entry->d_name[0])) {
                std::ifstream comm("/proc/" + std::string(entry->d_name) + "/comm");
                std::string line;
                if (getline(comm, line) && line == name) {
                    closedir(dir);
                    return std::stoi(entry->d_name);
                }
            }
        }
        closedir(dir);
        return 0;
    }

    static void start(const std::string& cmd) {
        std::string full_cmd = cmd + " > /dev/null 2>&1 &";
        system(full_cmd.c_str());
        sleep(2);
    }
};

int main() {

    std::string calc = "xcalc";
    std::string calendar = "gnome-calendar";

    setenv("PROC_TO_KILL", calendar.c_str(), 1);

    std::cout << "Тест 1: Удаление калькулятора по ID" << std::endl;
    ProcessManager::start(calc);
    pid_t pidC = ProcessManager::findPid(calc);
    if (pidC > 0) {
        std::cout << "Запущен " << calc << " " << pidC << std::endl;
        system(("./Killer --id " + std::to_string(pidC)).c_str());
        sleep(1);
        if (kill(pidC, 0) != 0) std::cout << "Удален" << std::endl;
    }

    std::cout << "\nТест 2: Удаление калькулятора по имени" << std::endl;
    ProcessManager::start(calc);
    if (ProcessManager::findPid(calc)) {
        std::cout << "Запущен " << calc << std::endl;
        system(("./Killer --name " + calc).c_str());
        sleep(1);
        if (!ProcessManager::findPid(calc)) std::cout << "Удален" << std::endl;
    }

    std::cout << "\nТест 3: Удаление через PROC_TO_KILL (календарь)" << std::endl;
    ProcessManager::start(calendar);
    if (ProcessManager::findPid(calendar)) {
        std::cout << "Запущен " << calendar << std::endl;
        system("./Killer --env");
        sleep(1);
        if (!ProcessManager::findPid(calendar)) std::cout << "Удален" << std::endl;
    }

    unsetenv("PROC_TO_KILL");
    return 0;
}


