﻿#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <tlhelp32.h>

class ProcessManager {
public:

    static DWORD findProcessIdByName(const std::wstring& targetName) {
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot == INVALID_HANDLE_VALUE) {
            return 0;
        }

        PROCESSENTRY32W pe; 
        pe.dwSize = sizeof(PROCESSENTRY32W);

        if (Process32FirstW(hSnapshot, &pe)) {  
            do {
                std::wstring currentName(pe.szExeFile);
                if (currentName == targetName) {
                    CloseHandle(hSnapshot);
                    return pe.th32ProcessID;
                }
            } while (Process32NextW(hSnapshot, &pe));  
        }

        CloseHandle(hSnapshot);
        return 0;
    }

    static bool processExists(DWORD processId) {
        HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, processId);
        if (hProcess == NULL) {
            return false;
        }
        CloseHandle(hProcess);
        return true;
    }

    static bool startProcess(const std::wstring& commandLine) {
        STARTUPINFOW si = { sizeof(si) };
        PROCESS_INFORMATION pi;

        wchar_t* cmdLine = _wcsdup(commandLine.c_str());

        BOOL success = CreateProcessW(
            NULL,          
            cmdLine,        
            NULL,           
            NULL,           
            FALSE,          
            0,              
            NULL,           
            NULL,           
            &si,            
            &pi             
        );

        free(cmdLine);

        if (success) {
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            return true;
        }

        return false;
    }
};

void demonstrateKiller() {

    SetEnvironmentVariableW(L"PROC_TO_KILL", L"mspaint.exe,CalculatorApp.exe,cmd.exe");

    std::cout << "\n1.Kill by name:" << std::endl;

    std::cout << "Starting Telegram.exe..." << std::endl;
    ProcessManager::startProcess(L"C:\\Users\\konst\\AppData\\Roaming\\Telegram Desktop\\Telegram.exe");
    Sleep(5000);

    DWORD tgPid = ProcessManager::findProcessIdByName(L"Telegram.exe");
    if (tgPid != 0) {
        std::cout << "Telegram started (PID: " << tgPid << ")" << std::endl;
        std::cout << "Starting Killer.exe --name Telegram.exe" << std::endl;
        ProcessManager::startProcess(L"Killer.exe --name Telegram.exe");
        Sleep(2000);
        if (!ProcessManager::processExists(tgPid)) {
            std::cout << "Telegram successfully terminated" << std::endl;
        }
        else {
            std::cout << "Telegram was not terminated" << std::endl;
        }
    }

    std::cout << "\n2.Kill by ID:" << std::endl;

    std::cout << "Starting CalculatorApp.exe" << std::endl;
    ProcessManager::startProcess(L"Calc.exe");
    Sleep(5000);

    DWORD clcPid = ProcessManager::findProcessIdByName(L"CalculatorApp.exe");
    if (clcPid != 0) {
        std::cout << "CalculatorApp started (PID: " << clcPid << ")" << std::endl;
        std::cout << "Starting Killer.exe --id " << clcPid << std::endl;
        std::wstring command = L"Killer.exe --id " + std::to_wstring(clcPid);
        ProcessManager::startProcess(command);
        Sleep(2000);

        if (!ProcessManager::processExists(clcPid)) {
            std::cout << "Calculator was successfully terminated" << std::endl;
        }
        else {
            std::cout << "Calculator was not terminated" << std::endl;
        }
    }

    std::cout << "\n3.Using PROC_TO_KILL" << std::endl;

    ProcessManager::startProcess(L"mspaint.exe");
    ProcessManager::startProcess(L"Calc.exe");
    ProcessManager::startProcess(L"cmd.exe");
    Sleep(2000);

    std::cout << "Starting Killer.exe --env" << std::endl;
    ProcessManager::startProcess(L"Killer.exe --env");
    Sleep(2000);

    SetEnvironmentVariableW(L"PROC_TO_KILL", NULL);

}

int main() {
    demonstrateKiller();

    std::cout << "\nPress Enter to exit..." << std::endl;
    std::cin.get();

    return 0;
}