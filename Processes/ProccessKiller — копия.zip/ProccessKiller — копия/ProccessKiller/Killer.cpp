#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <tlhelp32.h>

class ProcessKiller {
public:

    static bool killProcessById(DWORD processId) {
        HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, processId);
        if (hProcess == NULL) {
            std::cout << "Error" << processId << std::endl;
            return false;
        }

        BOOL result = TerminateProcess(hProcess, 0);
        CloseHandle(hProcess);

        if (result) {
            std::cout << "Process with ID " << processId << " terminated" << std::endl;
            return true;
        }
        else {
            std::cout << "Error" << processId << std::endl;
            return false;
        }
    }

    static std::vector<DWORD> findProcessesByName(const std::wstring& targetName) {
        std::vector<DWORD> foundIds;

        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot == INVALID_HANDLE_VALUE) {
            return foundIds;
        }

        PROCESSENTRY32W pe;  
        pe.dwSize = sizeof(PROCESSENTRY32W);

        if (Process32FirstW(hSnapshot, &pe)) {  
            do {
                std::wstring currentName(pe.szExeFile);
                if (currentName == targetName) {
                    foundIds.push_back(pe.th32ProcessID);
                }
            } while (Process32NextW(hSnapshot, &pe));  
        }

        CloseHandle(hSnapshot);
        return foundIds;
    }


    static bool killProcessesByName(const std::wstring& processName) {
        std::vector<DWORD> pids = findProcessesByName(processName);

        if (pids.empty()) {
            std::wcout << L"No processes found with name: " << processName << std::endl;
            return false;
        }

        std::wcout << L"Found " << pids.size() << L" processes with name: " << processName << std::endl;

        bool allKilled = true;
        for (DWORD pid : pids) {
            if (!killProcessById(pid)) {
                allKilled = false;
            }
        }

        return allKilled;
    }

    static void killProcessesFromEnvironment() {
        wchar_t buffer[1024];
        DWORD length = GetEnvironmentVariableW(L"PROC_TO_KILL", buffer, 1024);

        if (length == 0) {
            std::cout << "Environment variable PROC_TO_KILL not found" << std::endl;
            return;
        }

        std::wcout << L"PROC_TO_KILL: " << buffer << std::endl;

        std::wstring processes(buffer);
        std::vector<std::wstring> processList;

        std::wstringstream ss(processes);
        std::wstring item;
        while (std::getline(ss, item, L',')) {
            item.erase(0, item.find_first_not_of(L" \""));
            item.erase(item.find_last_not_of(L" \"") + 1);
            if (!item.empty()) {
                processList.push_back(item);
            }
        }
        for (const auto& processName : processList) {
            std::wcout << L"Killing processes: " << processName << std::endl;
            killProcessesByName(processName);
        }
    }
};

int main(int argc, char* argv[]) {

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];

        if (arg == "--id" && i + 1 < argc) {
            DWORD processId = std::stoul(argv[++i]);
            ProcessKiller::killProcessById(processId);
        }
        else if (arg == "--name" && i + 1 < argc) {
            std::string processName = argv[++i];
            std::wstring wideName(processName.begin(), processName.end());
            ProcessKiller::killProcessesByName(wideName);
        }
        else if (arg == "--env") {
            ProcessKiller::killProcessesFromEnvironment();
        }
    }
    return 0;
}