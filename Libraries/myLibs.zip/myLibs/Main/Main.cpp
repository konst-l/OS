#include <iostream>
#include "Number.h"
#include "Vector.h"

int main() {
    std::cout << "Number test\n";

    Number a = createNumber(10.0);
    Number b = createNumber(4.0);

    std::cout << "a = " << a.getValue() << std::endl;
    std::cout << "b = " << b.getValue() << std::endl;

    std::cout << "a + b = " << (a + b).getValue() << std::endl;
    std::cout << "a - b = " << (a - b).getValue() << std::endl;
    std::cout << "a * b = " << (a * b).getValue() << std::endl;
    std::cout << "a / b = " << (a / b).getValue() << std::endl;

    std::cout << "ZERO = " << ZERO.getValue() << std::endl;
    std::cout << "ONE  = " << ONE.getValue() << std::endl;

    std::cout << "\nVector test\n";

    Vector v1(createNumber(3.0), createNumber(4.0));
    Vector v2(createNumber(1.0), createNumber(2.0));

    std::cout << "v1 = ("
        << v1.getX().getValue() << ", "
        << v1.getY().getValue() << ")\n";

    std::cout << "v2 = ("
        << v2.getX().getValue() << ", "
        << v2.getY().getValue() << ")\n";

    Vector sum = v1 + v2;
    std::cout << "v1 + v2 = ("
        << sum.getX().getValue() << ", "
        << sum.getY().getValue() << ")\n";

    std::cout << "v1 radius = "
        << v1.getRadius().getValue() << std::endl;

    std::cout << "v1 angle  = "
        << v1.getAngle().getValue() << std::endl;

    std::cout << "\nVector constants:\n";

    std::cout << "ZERO_VECTOR = ("
        << ZERO_VECTOR.getX().getValue() << ", "
        << ZERO_VECTOR.getY().getValue() << ")\n";

    std::cout << "ONE_VECTOR = ("
        << ONE_VECTOR.getX().getValue() << ", "
        << ONE_VECTOR.getY().getValue() << ")\n";

    return 0;
}
