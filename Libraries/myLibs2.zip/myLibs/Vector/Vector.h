#pragma once

#ifdef VECTOR_EXPORTS
#define VECTOR_API __declspec(dllexport)
#else
#define VECTOR_API __declspec(dllimport)
#endif

#include "Number.h"

class VECTOR_API Vector {
    Number x;
    Number y;

public:
    Vector(const Number& x = ZERO, const Number& y = ZERO);

    Number getRadius() const;
    Number getAngle() const;
    Vector operator+(const Vector& other) const;

    Number getX() const;
    Number getY() const;
};

extern VECTOR_API const Vector ZERO_VECTOR;
extern VECTOR_API const Vector ONE_VECTOR;
