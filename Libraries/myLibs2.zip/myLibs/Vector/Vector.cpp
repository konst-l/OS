#define VECTOR_EXPORTS
#include "Vector.h"
#include <cmath>

Vector::Vector(const Number& x_, const Number& y_) : x(x_), y(y_) {}

Number Vector::getRadius() const {
    return createNumber(std::sqrt((x * x + y * y).getValue()));
}

Number Vector::getAngle() const {
    return createNumber(std::atan2(y.getValue(), x.getValue()));
}

Vector Vector::operator+(const Vector& o) const {
    return Vector(x + o.x, y + o.y);
}

Number Vector::getX() const { return x; }
Number Vector::getY() const { return y; }

const Vector ZERO_VECTOR(createNumber(0.0), createNumber(0.0));
const Vector ONE_VECTOR(createNumber(1.0), createNumber(1.0));
