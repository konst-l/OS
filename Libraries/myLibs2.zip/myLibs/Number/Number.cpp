#include "Number.h"
#include <stdexcept>

Number::Number(double v) : value(v) {}

Number Number::operator+(const Number& o) const { return Number(value + o.value); }
Number Number::operator-(const Number& o) const { return Number(value - o.value); }
Number Number::operator*(const Number& o) const { return Number(value * o.value); }
Number Number::operator/(const Number& o) const {
    if (o.value == 0) throw std::runtime_error("Division by zero");
    return Number(value / o.value);
}

double Number::getValue() const { return value; }

const Number ZERO(0.0);
const Number ONE(1.0);

Number createNumber(double value) {
    return Number(value);
}