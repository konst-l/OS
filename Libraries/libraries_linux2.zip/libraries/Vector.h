#ifndef VECTOR_H
#define VECTOR_H

#include "Number.h"

class Vector {
private:
    Number x, y;
public:
    Vector(Number x_val = ZERO, Number y_val = ZERO);
    
    Number getR() const;     
    Number getPhi() const;   

    Vector operator+(const Vector& other) const;
    
    Number getX() const { return x; }
    Number getY() const { return y; }
};

extern Vector V_ZERO;
extern Vector V_ONE;

#endif


