#include "Vector.h"
#include <cmath>

Vector::Vector(Number x_val, Number y_val) : x(x_val), y(y_val) {}

Number Vector::getR() const {
    return createNumber(std::sqrt(x.getValue() * x.getValue() + y.getValue() * y.getValue()));
}

Number Vector::getPhi() const {
    return createNumber(std::atan2(y.getValue(), x.getValue()));
}

Vector Vector::operator+(const Vector& other) const {
    return Vector(x + other.x, y + other.y);
}

Vector V_ZERO(ZERO, ZERO);
Vector V_ONE(1.0, 1.0);


