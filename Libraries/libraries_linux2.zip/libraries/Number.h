#ifndef NUMBER_H
#define NUMBER_H

class Number {
private:
    double value;
public:
    Number(double v = 0);
    double getValue() const;
    void setValue(double v);

    Number operator+(const Number& other) const;
    Number operator-(const Number& other) const;
    Number operator*(const Number& other) const;
    Number operator/(const Number& other) const;
};

extern Number ZERO;
extern Number ONE;

Number createNumber(double v);

#endif


