#include <iostream>
#include "Number.h"
#include "Vector.h"

int main() {
    std::cout << " Testing Number Library (Static) " << std::endl;
    Number n1 = createNumber(10.5);
    Number n2 = ONE;
    Number res = n1 + n2;
    std::cout << "10.5 + 1 = " << res.getValue() << std::endl;

    std::cout << "\n Testing Vector Library (Dynamic) " << std::endl;
    Vector v1(createNumber(3), createNumber(4)); 
    Vector v2 = V_ONE; 
    
    Vector v3 = v1 + v2; 
    
    std::cout << "Vector v3: (" << v3.getX().getValue() << ", " << v3.getY().getValue() << ")" << std::endl;
    std::cout << "Magnitude (R): " << v3.getR().getValue() << std::endl;
    std::cout << "Angle (Phi): " << v3.getPhi().getValue() << " rad" << std::endl;

    return 0;
}


