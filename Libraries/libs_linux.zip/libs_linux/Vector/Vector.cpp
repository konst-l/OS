#include "Vector.h"

Vector::Vector(Number x, Number y) : x(x), y(y) {}
Number Vector::getX() const { return x; }
Number Vector::getY() const { return y; }
void Vector::setX(Number nx) { x = nx; }
void Vector::setY(Number ny) { y = ny; }

Number Vector::magnitude() const {
    return createNumber(std::sqrt(x.getValue() * x.getValue() + y.getValue() * y.getValue()));
}

Number Vector::angle() const {
    return createNumber(std::atan2(y.getValue(), x.getValue()));
}

Vector Vector::operator+(const Vector& other) const {
    return Vector(x + other.x, y + other.y);
}

// Предопределенные векторы
Vector ZERO_VECTOR(ZERO, ZERO);
Vector ONE_VECTOR(ONE, ONE);



