#ifndef VECTOR_H
#define VECTOR_H

#include "../Number/Number.h"
#include <cmath>

class Vector {
private:
    Number x;
    Number y;
public:
    Vector(Number x = ZERO, Number y = ZERO);

    Number getX() const;
    Number getY() const;
    void setX(Number x);
    void setY(Number y);

    // Полярные координаты
    Number magnitude() const; // длина
    Number angle() const;     // угол в радианах

    Vector operator+(const Vector& other) const;
};

// Предопределенные векторы
extern Vector ZERO_VECTOR;
extern Vector ONE_VECTOR;

#endif



