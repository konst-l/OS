#include <iostream>
#include "Number/Number.h"
#include "Vector/Vector.h"


int main() {

    std::cout << "Number tests" << std::endl;
    std::cout << "ZERO = " << ZERO.getValue() << std::endl;
    std::cout << "ONE  = " << ONE.getValue() << std::endl;
    Number a = createNumber(5);
    Number b = ONE;


    std::cout << "a = " << a.getValue() << ", b = " << b.getValue() << std::endl;


    Number sum = a + b;
    Number diff = a - b;
    Number prod = a * b;
    Number quot = a / b;
    std::cout << "a + b = " << sum.getValue() << std::endl;
    std::cout << "a - b = " << diff.getValue() << std::endl;
    std::cout << "a * b = " << prod.getValue() << std::endl;
    std::cout << "a / b = " << quot.getValue() << std::endl;


    std::cout << "\nVector tests" << std::endl;
    std::cout << "ZERO_VECTOR = (" << ZERO_VECTOR.getX().getValue()
              << ", " << ZERO_VECTOR.getY().getValue() << ")" << std::endl;
    std::cout << "ONE_VECTOR  = (" << ONE_VECTOR.getX().getValue()
              << ", " << ONE_VECTOR.getY().getValue() << ")" << std::endl;


    Vector v1(a, b);
    Vector v2(ONE, createNumber(2));


    std::cout << "v1 = (" << v1.getX().getValue() << ", " << v1.getY().getValue() << ")" << std::endl;
    std::cout << "v2 = (" << v2.getX().getValue() << ", " << v2.getY().getValue() << ")" << std::endl;
     Vector v3 = v1 + v2;
    std::cout << "v3 = v1 + v2 = (" << v3.getX().getValue()
              << ", " << v3.getY().getValue() << ")" << std::endl;


    std::cout << "Magnitude(v3) = " << v3.magnitude().getValue() << std::endl;
    std::cout << "Angle(v3)     = " << v3.angle().getValue() << std::endl;


    Vector v4(ZERO, ONE);
    std::cout << "\nv4 = (0,1)" << std::endl;
    std::cout << "Magnitude(v4) = " << v4.magnitude().getValue() << std::endl;
    std::cout << "Angle(v4)     = " << v4.angle().getValue() << std::endl;


     Vector v5(ONE, ZERO);
    std::cout << "\nv5 = (1,0)" << std::endl;
    std::cout << "Magnitude(v5) = " << v5.magnitude().getValue() << std::endl;
    std::cout << "Angle(v5)     = " << v5.angle().getValue() << std::endl;


    return 0;
}
