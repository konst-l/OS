#ifndef NUMBER_H
#define NUMBER_H

class Number {
private:
    double value;
public:
    Number(double v = 0);
    double getValue() const;
    void setValue(double v);

    // Операции
    Number operator+(const Number& other) const;
    Number operator-(const Number& other) const;
    Number operator*(const Number& other) const;
    Number operator/(const Number& other) const;
};

// Предопределенные числа
extern Number ZERO;
extern Number ONE;

// Функция создания числа
Number createNumber(double v);

#endif
