#include "Number.h"
#include <stdexcept>

Number::Number(double v) : value(v) {}
double Number::getValue() const { return value; }
void Number::setValue(double v) { value = v; }

Number Number::operator+(const Number& other) const { return Number(value + other.value); }
Number Number::operator-(const Number& other) const { return Number(value - other.value); }
Number Number::operator*(const Number& other) const { return Number(value * other.value); }
Number Number::operator/(const Number& other) const {
    if (other.value == 0) throw std::runtime_error("Division by zero");
    return Number(value / other.value);
}

// Предопределенные числа
Number ZERO(0);
Number ONE(1);

// Функция создания числа
Number createNumber(double v) { return Number(v); }



